<?php
/**
 * The template for displaying the sidebar.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Libreria
 * @since   1.0.0
 */

// This theme doesn't have a traditional sidebar.
