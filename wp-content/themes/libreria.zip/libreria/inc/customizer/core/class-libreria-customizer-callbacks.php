<?php
/**
 * Libreria customizer class for theme customize callbacks.
 *
 * Class Libreria_Customizer_Callbacks
 *
 * @package    ThemeGrill
 * @subpackage Libreria
 * @since      Libreria 3.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Libreria customizer class for theme customize callbacks.
 *
 * Class Libreria_Customizer_Callbacks
 */
class Libreria_Customizer_Callbacks {

}
